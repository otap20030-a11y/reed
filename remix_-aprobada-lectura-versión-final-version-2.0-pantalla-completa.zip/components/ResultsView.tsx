
import React, { useRef } from 'react';
import { ReadingResult, ReadingLevel } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { WPM_STANDARDS } from '../constants';
import * as docx from 'docx';
import saveAs from 'file-saver';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

interface ResultsViewProps {
  result: ReadingResult;
  grade: number;
  studentName: string;
  onReset: () => void;
}

const ResultsView: React.FC<ResultsViewProps> = ({ result, grade, studentName, onReset }) => {
  const page1Ref = useRef<HTMLDivElement>(null);
  const page2Ref = useRef<HTMLDivElement>(null);
  const standard = WPM_STANDARDS[grade] || { min: 60, expected: 100 };

  const getLevelStyles = (level: ReadingLevel) => {
    switch (level) {
      case ReadingLevel.DESTACADO: 
        return { color: 'text-blue-700', bg: 'bg-blue-50', border: 'border-blue-200', icon: '🌟' };
      case ReadingLevel.NIVEL_ESPERADO: 
        return { color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200', icon: '✅' };
      case ReadingLevel.EN_DESARROLLO: 
        return { color: 'text-amber-700', bg: 'bg-amber-50', border: 'border-amber-200', icon: '⚠️' };
      case ReadingLevel.REQUIERE_APOYO: 
        return { color: 'text-rose-700', bg: 'bg-rose-50', border: 'border-rose-200', icon: '🆘' };
      default: 
        return { color: 'text-slate-700', bg: 'bg-slate-50', border: 'border-slate-200', icon: '📄' };
    }
  };

  const styles = getLevelStyles(result.level);

  const chartData = [
    { name: 'Alumno', value: result.wpm, fill: result.wpm >= standard.expected ? '#10b981' : (result.wpm >= standard.min ? '#f59e0b' : '#ef4444') },
    { name: 'Mínimo', value: standard.min, fill: '#94a3b8' },
    { name: 'Esperado', value: standard.expected, fill: '#6366f1' }
  ];

  const handleExportToPDF = async () => {
    if (!page1Ref.current || !page2Ref.current) return;

    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();

    // Capturar Página 1
    const canvas1 = await html2canvas(page1Ref.current, { scale: 2, useCORS: true, backgroundColor: '#f8fafc' });
    const imgData1 = canvas1.toDataURL('image/png');
    const imgHeight1 = (canvas1.height * pdfWidth) / canvas1.width;
    pdf.addImage(imgData1, 'PNG', 0, 0, pdfWidth, imgHeight1);

    // Añadir Página 2
    pdf.addPage();
    const canvas2 = await html2canvas(page2Ref.current, { scale: 2, useCORS: true, backgroundColor: '#f8fafc' });
    const imgData2 = canvas2.toDataURL('image/png');
    const imgHeight2 = (canvas2.height * pdfWidth) / canvas2.width;
    pdf.addImage(imgData2, 'PNG', 0, 0, pdfWidth, imgHeight2);

    pdf.save(`Reporte_SISAT_${studentName.replace(/\s+/g, '_') || 'Alumno'}.pdf`);
  };

  const handleExportToWord = async () => {
    const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, HeadingLevel, WidthType, AlignmentType } = docx;

    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            text: "REPORTE DE EVALUACIÓN DE LECTURA SISAT",
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 }
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "ALUMNO: ", bold: true }),
              new TextRun({ text: studentName.toUpperCase() || "SIN NOMBRE" }),
            ],
            spacing: { after: 200 }
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "GRADO: ", bold: true }),
              new TextRun({ text: `${grade}° de Primaria` }),
            ],
            spacing: { after: 200 }
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "FECHA: ", bold: true }),
              new TextRun({ text: new Date().toLocaleDateString('es-MX') }),
            ],
            spacing: { after: 400 }
          }),
          new Paragraph({
            text: "RESUMEN DE DESEMPEÑO",
            heading: HeadingLevel.HEADING_2,
            spacing: { after: 200 }
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "NIVEL ALCANZADO: ", bold: true }),
              new TextRun({ text: result.level.toUpperCase(), color: "10b981" }),
            ]
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "VELOCIDAD: ", bold: true }),
              new TextRun({ text: `${result.wpm} palabras por minuto` }),
            ]
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "PRECISIÓN: ", bold: true }),
              new TextRun({ text: `${result.accuracy}% de exactitud` }),
            ],
            spacing: { after: 400 }
          }),
          new Paragraph({
            text: "ANÁLISIS DE ERRORES",
            heading: HeadingLevel.HEADING_2,
            spacing: { after: 200 }
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ text: "TIPO", bold: true })] }),
                  new TableCell({ children: [new Paragraph({ text: "PALABRA LEÍDA", bold: true })] }),
                  new TableCell({ children: [new Paragraph({ text: "LO ESPERADO", bold: true })] }),
                ],
              }),
              ...result.errors.map(err => new TableRow({
                children: [
                  new TableCell({ children: [new Paragraph({ text: err.type.toUpperCase() })] }),
                  new TableCell({ children: [new Paragraph({ text: err.word })] }),
                  new TableCell({ children: [new Paragraph({ text: err.expected })] }),
                ]
              }))
            ],
          }),
          new Paragraph({
            text: "PLAN DE INTERVENCIÓN SUGERIDO",
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 400, after: 200 }
          }),
          ...result.suggestions.map((sug, i) => new Paragraph({
            text: `${i + 1}. ${sug}`,
            spacing: { after: 100 }
          })),
          new Paragraph({
            text: "TRANSCRIPCIÓN LITERAL",
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 400, after: 200 }
          }),
          new Paragraph({
            text: result.transcription,
            italics: true,
            color: "666666"
          })
        ],
      }],
    });

    const blob = await Packer.toBlob(doc);
    if (typeof saveAs === 'function') {
      saveAs(blob, `Reporte_SISAT_${studentName.replace(/\s+/g, '_') || 'Alumno'}.docx`);
    } else if ((saveAs as any).saveAs) {
      (saveAs as any).saveAs(blob, `Reporte_SISAT_${studentName.replace(/\s+/g, '_') || 'Alumno'}.docx`);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* SECCIÓN PÁGINA 1 PDF */}
      <div ref={page1Ref} className="space-y-6 p-4 bg-slate-50 rounded-xl">
        {/* Header Alumno para PDF */}
        <div className="bg-white px-8 py-6 rounded-2xl border shadow-sm flex items-center justify-between">
          <div>
            <h2 className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Reporte Individual SISAT</h2>
            <p className="text-2xl font-black text-slate-800">{studentName.toUpperCase() || 'ALUMNO SIN NOMBRE'}</p>
            <p className="text-xs font-bold text-emerald-600">{grade}° de Primaria</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-black text-slate-400">FECHA DE EVALUACIÓN</p>
            <p className="text-sm font-bold text-slate-600">{new Date().toLocaleDateString('es-MX')}</p>
          </div>
        </div>

        {/* Main Score Card */}
        <div className={`p-10 rounded-3xl border-2 shadow-lg text-center relative overflow-hidden ${styles.bg} ${styles.border}`}>
          <div className="absolute top-4 right-6 text-4xl opacity-20">{styles.icon}</div>
          <h2 className="text-sm font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Nivel de Desempeño</h2>
          <div className={`text-5xl font-black mb-4 uppercase tracking-tight ${styles.color}`}>{result.level}</div>
          <div className="flex justify-center gap-8 mt-6">
            <div className="text-center">
              <span className="block text-3xl font-black text-slate-800">{result.wpm}</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">PPM (Velocidad)</span>
            </div>
            <div className="w-px h-12 bg-slate-200"></div>
            <div className="text-center">
              <span className="block text-3xl font-black text-slate-800">{result.accuracy}%</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Precisión</span>
            </div>
          </div>
        </div>

        {/* Comparison Chart */}
        <div className="bg-white p-8 rounded-3xl border shadow-sm">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6 text-center">Gráfica Comparativa vs Estándar Nacional</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 'bold', fill: '#64748b' }} />
                <YAxis hide />
                <Tooltip cursor={{ fill: 'transparent' }} content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-2 shadow-xl border rounded-lg text-xs font-bold text-slate-700">
                        {payload[0].value} PPM
                      </div>
                    );
                  }
                  return null;
                }} />
                <Bar dataKey="value" radius={[12, 12, 0, 0]} barSize={50}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* SECCIÓN PÁGINA 2 PDF */}
      <div ref={page2Ref} className="space-y-6 p-4 bg-slate-50 rounded-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Error Breakdown */}
          <div className="bg-white p-8 rounded-3xl border shadow-sm flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Análisis de Errores</h3>
              <span className={`px-3 py-1 rounded-full text-[10px] font-black ${result.errors.length > 5 ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                {result.errors.length} CASOS
              </span>
            </div>
            <div className="space-y-3 flex-grow overflow-y-visible">
              {result.errors.length > 0 ? (
                result.errors.map((err, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <div>
                      <span className="text-[9px] font-black text-rose-500 uppercase tracking-tighter mr-2">{err.type}</span>
                      <p className="text-sm font-bold text-slate-700 line-through opacity-40">{err.word}</p>
                      <p className="text-xs font-medium text-emerald-600 italic">Corrección: {err.expected}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center h-full py-10 opacity-40">
                  <p className="text-sm font-bold">Sin errores detectados</p>
                </div>
              )}
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-indigo-900 p-8 rounded-3xl text-white shadow-xl flex flex-col">
            <div className="flex items-center gap-3 mb-6">
              <h3 className="text-sm font-bold text-indigo-300 uppercase tracking-widest">Plan de Apoyo</h3>
            </div>
            <div className="space-y-4">
              {result.suggestions.map((sug, idx) => (
                <div key={idx} className="bg-indigo-800/50 p-4 rounded-2xl border border-indigo-700/50">
                  <p className="text-xs leading-relaxed text-indigo-100"><span className="font-black mr-2">{idx + 1}.</span>{sug}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Transcription */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Evidencia: Transcripción Literal</h3>
          <p className="text-xs text-slate-500 italic leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
            "{result.transcription}"
          </p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row justify-center gap-4 pt-8">
        <button
          onClick={handleExportToPDF}
          className="flex items-center justify-center gap-2 px-8 py-4 bg-rose-600 text-white font-black rounded-2xl shadow-xl hover:bg-rose-700 hover:scale-105 active:scale-95 transition-all uppercase tracking-widest text-xs"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
          Descargar PDF (2 Hojas)
        </button>

        <button
          onClick={handleExportToWord}
          className="flex items-center justify-center gap-2 px-8 py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl hover:bg-blue-700 hover:scale-105 active:scale-95 transition-all uppercase tracking-widest text-xs"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          Reporte Word
        </button>
        
        <button
          onClick={onReset}
          className="flex items-center justify-center gap-2 px-8 py-4 bg-slate-900 text-white font-black rounded-2xl shadow-2xl hover:bg-slate-800 hover:scale-105 active:scale-95 transition-all uppercase tracking-widest text-xs"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
          </svg>
          Nueva Evaluación
        </button>
      </div>
    </div>
  );
};

export default ResultsView;
