
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { ReadingResult, ReadingLevel } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeReadingAudio(
  audioBase64: string,
  expectedText: string,
  grade: number,
  durationSeconds: number
): Promise<ReadingResult> {
  const model = 'gemini-3-flash-preview';

  const systemPrompt = `
    Eres un evaluador especializado en el Sistema de Alerta Temprana (SISAT) de la SEP en México.
    Tu tarea es evaluar la lectura en voz alta de un alumno de ${grade}° de primaria.
    
    Texto esperado: "${expectedText}"
    Duración de la grabación: ${durationSeconds} segundos.

    Criterios de evaluación SISAT:
    1. Fluidez: Capacidad de leer con un ritmo constante, sin silabeos excesivos y respetando la puntuación.
    2. Velocidad: Palabras por minuto (PPM). 
    3. Precisión: Errores cometidos (omisiones, sustituciones, adiciones).

    Niveles SISAT:
    - Nivel Esperado: Lee con fluidez, velocidad adecuada para el grado y mínima cantidad de errores.
    - En Desarrollo: Lee con cierta fluidez pero presenta errores frecuentes o ritmo inconsistente.
    - Requiere Apoyo: Lectura silábica, muy lenta o con gran cantidad de errores que impiden la comprensión.

    Instrucciones de salida:
    - Identifica palabras exactas donde hubo errores.
    - Calcula PPM reales.
    - Clasifica en un nivel SISAT oficial.
    - Proporciona 3 sugerencias prácticas para el docente o padre de familia.
  `;

  const response = await ai.models.generateContent({
    model: model,
    contents: [
      {
        parts: [
          { text: systemPrompt },
          {
            inlineData: {
              mimeType: 'audio/wav',
              data: audioBase64
            }
          }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          wpm: { type: Type.NUMBER, description: "Palabras por minuto leídas" },
          accuracy: { type: Type.NUMBER, description: "Porcentaje de precisión" },
          errors: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                word: { type: Type.STRING, description: "Palabra errónea detectada" },
                type: { type: Type.STRING, enum: ['omision', 'sustitucion', 'adicion', 'pronunciacion'] },
                expected: { type: Type.STRING, description: "Lo que el texto decía" }
              }
            }
          },
          level: { 
            type: Type.STRING, 
            enum: [
                ReadingLevel.REQUIERE_APOYO, 
                ReadingLevel.EN_DESARROLLO, 
                ReadingLevel.NIVEL_ESPERADO, 
                ReadingLevel.DESTACADO
            ] 
          },
          suggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          transcription: { type: Type.STRING, description: "Lo que el alumno dijo literalmente" }
        },
        required: ["wpm", "accuracy", "errors", "level", "suggestions", "transcription"]
      }
    }
  });

  try {
    const textResult = response.text;
    if (!textResult) throw new Error("Respuesta vacía del servidor.");
    return JSON.parse(textResult.trim()) as ReadingResult;
  } catch (error) {
    console.error("Error parsing Gemini response:", error);
    throw new Error("No se pudo procesar la evaluación. Asegúrate de que el audio sea claro.");
  }
}
