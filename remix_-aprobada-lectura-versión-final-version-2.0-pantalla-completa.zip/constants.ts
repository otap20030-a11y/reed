
import { GradeText } from './types';

export const MEXICAN_READING_TEXTS: GradeText[] = [
  {
    id: '1',
    grade: 1,
    title: 'El Gato y la Pelota',
    content: 'Mina es una gatita muy juguetona. Ella tiene una pelota de color rojo. Todos los días salta en el jardín y corre detrás de su juguete favorito. Su mamá la mira y se pone muy feliz.',
    wordCount: 38
  },
  {
    id: '2',
    grade: 2,
    title: 'El Campo de Flores',
    content: 'En primavera, el campo se llena de flores de muchos colores. Las abejas vuelan de una flor a otra buscando néctar para hacer miel. Los niños corren con cuidado para no pisar las plantas pequeñas que apenas están creciendo.',
    wordCount: 42
  },
  {
    id: '3',
    grade: 3,
    title: 'La Leyenda del Conejo en la Luna',
    content: 'Hace mucho tiempo, el dios Quetzalcóatl decidió bajar a la Tierra. Caminó por las montañas y los valles hasta que se sintió muy cansado. Un pequeño conejo le ofreció su comida y, en agradecimiento, el dios lo elevó hasta la Luna para que su figura quedara grabada por siempre.',
    wordCount: 55
  },
  {
    id: '4',
    grade: 4,
    title: 'Los Bosques de México',
    content: 'México tiene una gran variedad de bosques. En las zonas altas encontramos pinos y encinos que se mantienen verdes durante todo el año. Estos lugares son el hogar de muchos animales como el venado cola blanca y diversas aves que cantan al amanecer.',
    wordCount: 48
  },
  {
    id: '5',
    grade: 5,
    title: 'Benito Juárez y el Respeto',
    content: 'Benito Juárez fue un presidente de México que nació en un pequeño pueblo de Oaxaca. Él creía firmemente que el respeto al derecho ajeno es la paz. Trabajó mucho para que todas las personas tuvieran los mismos derechos y defendió la soberanía de nuestra nación con valentía.',
    wordCount: 52
  },
  {
    id: '6',
    grade: 6,
    title: 'El Espacio y los Planetas',
    content: 'El sistema solar está compuesto por una estrella central llamada Sol y ocho planetas que giran a su alrededor. La Tierra es el único lugar conocido que alberga vida gracias a su atmósfera y agua líquida. La exploración espacial nos permite comprender mejor nuestro origen y el futuro de la humanidad en el universo.',
    wordCount: 58
  }
];

export const WPM_STANDARDS: Record<number, { min: number, expected: number }> = {
  1: { min: 35, expected: 59 },
  2: { min: 60, expected: 84 },
  3: { min: 85, expected: 99 },
  4: { min: 100, expected: 114 },
  5: { min: 115, expected: 124 },
  6: { min: 125, expected: 134 }
};
