
export enum ReadingLevel {
  REQUIERE_APOYO = "Requiere apoyo",
  EN_DESARROLLO = "En desarrollo",
  NIVEL_ESPERADO = "Nivel esperado",
  DESTACADO = "Destacado"
}

export interface ReadingError {
  word: string;
  type: 'omision' | 'sustitucion' | 'adicion' | 'pronunciacion';
  expected: string;
}

export interface ReadingResult {
  wpm: number; // Words per minute
  accuracy: number; // Percentage
  errors: ReadingError[];
  level: ReadingLevel;
  suggestions: string[];
  transcription: string;
}

export interface GradeText {
  id: string;
  grade: number;
  title: string;
  content: string;
  wordCount: number;
}
